package processor.pipeline;

public class EX_IF_LatchType {
	int inc = 0;
	boolean isbranch = false;
	public EX_IF_LatchType()
	{
		
	}

}
